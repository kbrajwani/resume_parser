from resume_parser.resumeparse import resumeparse

__all__ = [
    'resumeparse'
]